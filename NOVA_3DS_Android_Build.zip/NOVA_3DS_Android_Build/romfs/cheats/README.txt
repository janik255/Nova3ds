Local cheat catalog support is not implemented in this prototype.
