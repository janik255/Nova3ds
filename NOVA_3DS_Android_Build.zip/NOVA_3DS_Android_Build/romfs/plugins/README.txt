Plugin loading is not implemented in this prototype. Do not copy unknown executable plugins.
