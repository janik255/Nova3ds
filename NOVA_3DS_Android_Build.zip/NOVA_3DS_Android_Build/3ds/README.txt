Copy a built NOVA_3DS.3dsx to SD:/3ds/ if you use the Homebrew Launcher.
